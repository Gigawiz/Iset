# NMServer
The server can be started without the startup parameters.
Then the -perver option will be true
you can set the startup parameters separately for example, you can set the -server=http://yourserver and -pserver=false parameters in the boxes to get post requests to your web server 
post name userID and password

http://forum.ragezone.com/f943/nmserver-source-1138191/




https://golang.org/dl/
https://sourceforge.net/projects/liteide/
